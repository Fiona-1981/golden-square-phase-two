class HolidayPlanner
  def initialize
    @availabilities = []
  end

  def mark_friend_available(friend_name, date_from, date_to)
    # friend_name is a String
    # from and to are Date objects
    # add this friend's availability to the list
    # doesn't return anything
    @availabilities << {
      friend_name: friend_name,
      date_from: date_from,
      date_to: date_to
    }
  end

  def list_friends_available_on_day(date)
    friends_available = []
    @availabilities.each do |availability|
      # if the given date is between date_from and date_to
      if availability[:date_from] <= date && date <= availability[:date_to]
        friends_available << availability[:friend_name]
      end
    end

    return friends_available.sort
  end

  def find_first_range_where_all_friends_available()
    # returns an array of two elements (Date objects): start of the range, end of the range
    # returns nil if no range is found where all of my friends are available

    # sort them by earliest from
    sorted_availabilities = @availabilities.sort_by { |availability| availability[:date_from] }
    earliest_from = sorted_availabilities.first[:date_from]
    latest_to = sorted_availabilities.last[:date_to]

    first_date, last_date = try_to_find_range(earliest_from, latest_to)

    return nil if first_date.nil? || last_date.nil?

    return [first_date, last_date]
  end

  private

  def try_to_find_range(earliest_from, latest_to)
    first_date = nil
    last_date = nil

    (earliest_from..latest_to).each do |day|
      # IF everyone is available that day AND I don't have a first day for the range yet
      if list_friends_available_on_day(day).length == @availabilities.length && first_date.nil?
        # This day is the first day of the range
        first_date = day
      end

      # IF we have a first day for the range AND not everyone is available
      if first_date && list_friends_available_on_day(day).length < @availabilities.length
        last_date = day.prev_day
        break
      end
    end

    return [first_date, last_date]
  end
end