require 'holiday_planner'
require 'date'

RSpec.describe HolidayPlanner do
  it 'should return an empty array' do
    planner = HolidayPlanner.new
    expect(planner.list_friends_available_on_day(Date.new(2023, 02, 21))).to eq([])
  end

  context 'with two friends' do
    before do
      @planner = HolidayPlanner.new
      @planner.mark_friend_available("Sarah", Date.new(2023, 01, 01), Date.new(2023, 01, 05))
      @planner.mark_friend_available("Josh",  Date.new(2023, 01, 03), Date.new(2023, 01, 10))
    end

    it 'returns no friends' do
      expect(@planner.list_friends_available_on_day(Date.new(2023, 01, 31))).to eq([])
    end
    
    it 'returns one friend' do
      expect(@planner.list_friends_available_on_day(Date.new(2023, 01, 02))).to eq(["Sarah"])
    end
    
    it 'returns two friends' do
      expect(@planner.list_friends_available_on_day(Date.new(2023, 01, 04))).to eq(["Josh", "Sarah"])
    end
  end

  context 'with three friends' do
    before do
      @planner = HolidayPlanner.new
      @planner.mark_friend_available("Sarah", Date.new(2023, 01, 01), Date.new(2023, 01, 05))
      @planner.mark_friend_available("Josh",  Date.new(2023, 01, 03), Date.new(2023, 01, 10))
      @planner.mark_friend_available("Valeria",  Date.new(2023, 01, 04), Date.new(2023, 01, 12))
    end

    it 'returns no friend' do
      expect(@planner.list_friends_available_on_day(Date.new(2023, 01, 31))).to eq([])
    end

    it 'returns one friend' do
      expect(@planner.list_friends_available_on_day(Date.new(2023, 01, 02))).to eq(["Sarah"])
    end

    it 'returns all three friends' do
      expect(@planner.list_friends_available_on_day(Date.new(2023, 01, 04))).to eq(["Josh", "Sarah", "Valeria"])
    end

    it 'returns two friends' do
      expect(@planner.list_friends_available_on_day(Date.new(2023, 01, 06))).to eq(["Josh", "Valeria"])
    end

  end

  it 'returns the range of date where all these three friends are available' do
    planner = HolidayPlanner.new
    planner.mark_friend_available("Sarah", Date.new(2023, 01, 01), Date.new(2023, 01, 05))
    planner.mark_friend_available("Valeria",  Date.new(2023, 01, 04), Date.new(2023, 01, 12))
    planner.mark_friend_available("Josh",  Date.new(2023, 01, 03), Date.new(2023, 01, 10))

    date_range = planner.find_first_range_where_all_friends_available
    # => [Date.new(2023, 01, 04), Date.new(2023, 01, 05)]

    expect(date_range.first).to eq(Date.new(2023, 01, 04))
    expect(date_range.last).to eq(Date.new(2023, 01, 05))
  end

  it 'returns the range of date where all these three friends are available' do
    planner = HolidayPlanner.new
    planner.mark_friend_available("Sarah", Date.new(2023, 01, 01), Date.new(2023, 01, 07))
    planner.mark_friend_available("Valeria",  Date.new(2023, 01, 04), Date.new(2023, 01, 12))
    planner.mark_friend_available("Josh",  Date.new(2023, 01, 03), Date.new(2023, 01, 10))

    date_range = planner.find_first_range_where_all_friends_available
    # => [Date.new(2023, 01, 04), Date.new(2023, 01, 07)]

    expect(date_range.first).to eq(Date.new(2023, 01, 04))
    expect(date_range.last).to eq(Date.new(2023, 01, 07))
  end

  it 'returns nil as no range is found where everyone is available' do
    # 5 - three friends
    planner = HolidayPlanner.new
    planner.mark_friend_available("Sarah", Date.new(2023, 01, 01), Date.new(2023, 01, 05))
    planner.mark_friend_available("Valeria",  Date.new(2023, 01, 04), Date.new(2023, 01, 12))
    planner.mark_friend_available("Josh",  Date.new(2023, 01, 15), Date.new(2023, 01, 20))

    expect(planner.find_first_range_where_all_friends_available).to eq(nil)
  end
end