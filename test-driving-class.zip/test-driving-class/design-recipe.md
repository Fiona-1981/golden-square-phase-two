# {{PROBLEM}} Class Design Recipe

## 1. Describe the Problem

As a user
So I can know when my friends are available for holiday
I want to add my friends availabilities.

As a user
So I can know when my friends are available for holiday
I want to see a list of my friends available on a given day.

As a user
So I can know when my friends are available for holiday
I want to find the first range of dates where *all* of my friends are available.

 * How do I store availabilities?
 * What if none of my freinds are available on a given day?
 * What if there's no range of dates where all my friends are available?

## 2. Design the Class Interface

_Include the initializer and public methods with all parameters and return values._

```ruby
# EXAMPLE

class HolidayPlanner
  def initialize
  end

  def mark_friend_available(friend_name, date_from, date_to)
    # friend_name is a String
    # from and to are Date objects
    # add this friend's availability to the list
    # doesn't return anything
  end

  def list_friends_available_on_day(date)
    # date is a Date object
    # returns an array of friend names (Strings) available on that date
    # sorted by alphabetical order
  end

  def find_first_range_where_all_friends_available()
    # returns an array of two elements (Date objects): start of the range, end of the range
    # returns nil if no range is found where all of my friends are available
  end
end
```

## 3. Create Examples as Tests

_Make a list of examples of how the class will behave in different situations._

```ruby
# EXAMPLE

# 1 - no availabilities registered
planner = HolidayPlanner.new
planner.list_friends_available_on_day(Date.new(2023, 02, 21)) # => []

# 2 - two friends
planner = HolidayPlanner.new
planner.mark_friend_available("Sarah", Date.new(2023, 01, 01), Date.new(2023, 01, 05))
planner.mark_friend_available("Josh",  Date.new(2023, 01, 03), Date.new(2023, 01, 10))
planner.list_friends_available_on_day(Date.new(2023, 01, 31)) # => []
planner.list_friends_available_on_day(Date.new(2023, 01, 02)) # => ["Sarah"]
planner.list_friends_available_on_day(Date.new(2023, 01, 04)) # => ["Josh", "Sarah"]

# 3 - three friends
planner = HolidayPlanner.new
planner.mark_friend_available("Sarah", Date.new(2023, 01, 01), Date.new(2023, 01, 05))
planner.mark_friend_available("Josh",  Date.new(2023, 01, 03), Date.new(2023, 01, 10))
planner.mark_friend_available("Valeria",  Date.new(2023, 01, 04), Date.new(2023, 01, 12))
planner.list_friends_available_on_day(Date.new(2023, 01, 31)) # => []
planner.list_friends_available_on_day(Date.new(2023, 01, 02)) # => ["Sarah"]
planner.list_friends_available_on_day(Date.new(2023, 01, 04)) # => ["Josh", "Sarah", "Valeria"]
planner.list_friends_available_on_day(Date.new(2023, 01, 06)) # => ["Josh", "Valeria"]

# 4 - three friends
planner = HolidayPlanner.new
planner.mark_friend_available("Sarah", Date.new(2023, 01, 01), Date.new(2023, 01, 05))
planner.mark_friend_available("Valeria",  Date.new(2023, 01, 04), Date.new(2023, 01, 12))
planner.mark_friend_available("Josh",  Date.new(2023, 01, 03), Date.new(2023, 01, 10))

planner.find_first_range_where_all_friends_available # => [Date.new(2023, 01, 04), Date.new(2023, 01, 05)]

# 5 - three friends
planner = HolidayPlanner.new
planner.mark_friend_available("Sarah", Date.new(2023, 01, 01), Date.new(2023, 01, 05))
planner.mark_friend_available("Valeria",  Date.new(2023, 01, 04), Date.new(2023, 01, 12))
planner.mark_friend_available("Josh",  Date.new(2023, 01, 15), Date.new(2023, 01, 20))

planner.find_first_range_where_all_friends_available # => nil


```

_Encode each example as a test. You can add to the above list as you go._

## 4. Implement the Behaviour

_After each test you write, follow the test-driving process of red, green, refactor to implement the behaviour._
